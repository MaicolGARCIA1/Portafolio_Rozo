import React from 'react'
import './Footer.css'

export default function Footer() {
  return (
    <footer>
      <br />
      <br />
        Portafolio 2023 / Maicol García
        <div className='Btn_Footer'>
        <button>↑</button>
        </div>
    </footer>
  )
}
