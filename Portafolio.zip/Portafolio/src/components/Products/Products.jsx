export const  Products =()  =>{
  return (
      <div className='w-96 h-80 bg-slate-600 mt-8 rounded-2x1 flex  items-center justify-center'>
        <img className='w-full h-28 bg-slate-600'src="https://staticsnews.medsbla.com/news-es/wp-content/uploads/2018/12/09114807/dac54478ce6008a0bd40d8302d1e7d976dec8ea1.jpg" alt="" />
        <h2>Category</h2>
        <div>
        <p>Title</p>
        <p>$Price</p>
      </div>
    </div>
  )
}
